# LyricsPlus Link (aplikasi Android) — tanpa Termux

Aplikasi ini membaca lagu yang sedang diputar di Spotify / YouTube Music (judul, artis, durasi, dan POSISI lagu yang
sebenarnya, jadi jeda/lompat ikut terbaca), mencari liriknya di lrclib.net, lalu mengirimnya ke Minecraft lewat /connect.
Tidak perlu Termux, Termux:API, Premium, atau web player.

PENTING: file ini adalah kode sumber. Kode aplikasi belum bisa dibangun/diuji di tempat saya, jadi build pertama bisa
saja menampilkan galat. Kalau gagal, kirim foto/salinan log yang merah, nanti saya perbaiki.

## A. Membangun APK (sekali saja, gratis, lewat GitHub)
Butuh akun GitHub (gratis) dan sebaiknya komputer (upload folder lebih mudah). Dari HP bisa, tapi lebih lama.

1. Buka github.com, daftar/masuk. Tekan "+" > "New repository". Nama: lyricsplus-link. Pilih Private atau Public. Create.
2. Ekstrak LyricsPlus_Link_Android.zip.
3. Upload isi folder ke repositori:
   - Di komputer: halaman repositori > "uploading an existing file" > seret SEMUA isi folder (app, build.gradle,
     settings.gradle, gradle.properties). Folder `.github` kadang tidak ikut terseret -> lakukan langkah 4.
   - Di HP: tidak bisa upload folder. Buat tiap file lewat "Add file" > "Create new file", ketik nama lengkap dengan
     garis miring (mis. `app/src/main/AndroidManifest.xml`) lalu tempel isinya. Total 10 file.
4. Pastikan ada file `.github/workflows/build.yml` (kalau belum: Add file > Create new file, ketik nama
   `.github/workflows/build.yml`, tempel isi file itu dari zip, Commit).
5. Buka tab "Actions". Pilih "Bangun APK" > "Run workflow" (atau otomatis jalan setelah upload). Tunggu 3-6 menit sampai
   centang hijau.
6. Buka hasil jalannya > bagian "Artifacts" > unduh "LyricsPlusLink-apk" (zip) > ekstrak > `app-debug.apk`.
7. Pasang APK di HP (izinkan "pasang dari sumber ini" kalau diminta).

## B. Memakai (tiap kali)
1. Buka aplikasi "LyricsPlus Link". Tekan tombol 1, nyalakan "LyricsPlus Link" di daftar Akses notifikasi.
2. Tekan tombol 2, pilih LyricsPlus Link > Tanpa batasan (supaya tidak dimatikan Xiaomi). Kunci aplikasi di layar
   aplikasi terbaru.
3. Pasang add-on LyricsPlus_v2.6.mcaddon, aktifkan, cheat hidup, matikan "Wajibkan WebSocket terenkripsi".
4. Di Minecraft chat: `/connect 127.0.0.1:8974`
5. Putar lagu di Spotify atau YouTube Music. Lirik muncul otomatis, ganti lagu = lirik ganti, jeda ikut terbaca.

Chat Minecraft: `!geser 0.5` / `!geser -0.5` (sinkron), `!reset`, `!status`, `!bantuan`.
Layar aplikasi menunjukkan status: akses notifikasi, server, Minecraft, lagu, dan log.
