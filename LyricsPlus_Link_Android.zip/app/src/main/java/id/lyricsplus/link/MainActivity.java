package id.lyricsplus.link;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView status, logs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refresh = new Runnable() {
        @Override public void run() { render(); handler.postDelayed(this, 1000); }
    };

    private boolean listenerEnabled() {
        String s = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return s != null && s.contains(getPackageName());
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false); b.setOnClickListener(l); return b;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(pad, pad, pad, pad);
        TextView h = new TextView(this); h.setText("LyricsPlus Link"); h.setTextSize(24); root.addView(h);
        TextView sub = new TextView(this); sub.setText("Lirik Spotify / YouTube Music ke Minecraft Bedrock, tanpa Termux."); root.addView(sub);
        root.addView(button("1. Izinkan akses notifikasi", v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))));
        root.addView(button("2. Lepas batas baterai (supaya tidak dimatikan)", v -> startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))));
        root.addView(button("3. Salin perintah /connect", v -> {
            ((ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("connect", "/connect 127.0.0.1:" + Core.PORT));
            Toast.makeText(this, "Disalin. Tempel di chat Minecraft.", Toast.LENGTH_LONG).show();
        }));
        status = new TextView(this); status.setTextSize(16); status.setPadding(0, pad, 0, pad); root.addView(status);
        logs = new TextView(this); logs.setTextSize(12); logs.setTypeface(android.graphics.Typeface.MONOSPACE);
        ScrollView sv = new ScrollView(this); sv.addView(logs); root.addView(sv);
        setContentView(root);
    }

    @Override protected void onResume() {
        super.onResume();
        Core.I.start();
        try { NotificationListenerService.requestRebind(new ComponentName(this, NotifService.class)); } catch (Throwable ignored) {}
        handler.post(refresh);
    }

    @Override protected void onPause() { handler.removeCallbacks(refresh); super.onPause(); }

    private void render() {
        boolean perm = listenerEnabled();
        status.setText("Akses notifikasi: " + (perm ? "AKTIF" : "BELUM (tekan tombol 1)")
            + "\nServer /connect: " + (Core.I.isStarted() ? "jalan di 127.0.0.1:" + Core.PORT : "mati")
            + "\nMinecraft: " + (Core.I.connectedCount() > 0 ? "TERHUBUNG" : "belum (ketik /connect 127.0.0.1:" + Core.PORT + ")")
            + "\nMusik: " + Core.I.nowPlaying());
        logs.setText(Core.I.recentLogs());
    }
}
