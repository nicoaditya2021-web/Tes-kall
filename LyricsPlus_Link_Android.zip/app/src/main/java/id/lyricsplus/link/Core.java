package id.lyricsplus.link;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.regex.*;

/** Inti LyricsPlus Link (Java murni, tanpa Android): server WebSocket untuk /connect Minecraft + pencari lirik lrclib. */
public final class Core {
    public static final Core I = new Core();
    public static final int PORT = 8974;
    static final String GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
    static final int CHUNK = 350;
    public static String LRCLIB = "https://lrclib.net";

    // ---- keadaan lagu ----
    static final class Line { final double t; final String text; Line(double t, String s) { this.t = t; this.text = s; } }
    private final Object lock = new Object();
    private String id = null, title = "", artist = "", lyricsStatus = "-", key = "";
    private double duration = 0, anchorPos = 0, offset = 0, speed = 1;
    private long anchorNs = 0;
    private boolean playing = false;
    private List<Line> lines = new ArrayList<>();
    private List<String> chunks = new ArrayList<>();
    private int fetchGen = 0;
    private volatile int connected = 0;
    private volatile long lastMedia = 0;
    private final List<String> logs = new ArrayList<>();
    private final List<List<String>> queues = new ArrayList<>();
    private ServerSocket server;
    private boolean started = false;

    public void log(String s) {
        synchronized (logs) { logs.add(new java.text.SimpleDateFormat("HH:mm:ss").format(new Date()) + " " + s); while (logs.size() > 40) logs.remove(0); }
    }
    public String recentLogs() { synchronized (logs) { return String.join("\n", logs); } }
    public int connectedCount() { return connected; }
    public boolean mediaRecent() { return System.currentTimeMillis() - lastMedia < 5000; }
    public String nowPlaying() { synchronized (lock) { return id == null ? "(belum ada lagu)" : artist + " - " + title + " [" + (playing ? "main" : "jeda") + ", lirik " + lines.size() + " baris: " + lyricsStatus + "]"; } }
    public boolean isStarted() { return started; }

    // ---- dipanggil oleh pembaca sesi media ----
    public void update(String ttl, String art, double durSec, boolean isPlaying, double posSec, float spd) {
        lastMedia = System.currentTimeMillis();
        ttl = ttl == null ? "" : ttl.trim(); art = art == null ? "" : art.trim();
        if (ttl.isEmpty()) return;
        String low = ttl.toLowerCase();
        if (low.equals("advertisement") || low.equals("iklan") || low.equals("spotify")) return;   // lewati iklan
        String k = (art + "|" + ttl).toLowerCase();
        synchronized (lock) {
            if (!k.equals(key)) {
                key = k; title = ttl; artist = art; id = "m-" + Integer.toHexString(k.hashCode());
                duration = durSec; lines = new ArrayList<>(); chunks = new ArrayList<>(); lyricsStatus = "mencari...";
                anchorPos = posSec; anchorNs = System.nanoTime(); speed = spd <= 0 ? 1 : spd; playing = isPlaying;
                final int gen = ++fetchGen; final String ft = ttl, fa = art; final double fd = durSec;
                log("Terdeteksi: " + (art.isEmpty() ? "-" : art) + " - " + ttl);
                Thread t = new Thread(() -> fetchLyrics(gen, ft, fa, fd)); t.setDaemon(true); t.start();
                return;
            }
            if (durSec > 0) duration = durSec;
            double cur = positionRaw();
            if (isPlaying != playing || Math.abs(cur - posSec) > 0.35 || spd != speed) {   // koreksi hanya jika meleset
                anchorPos = posSec; anchorNs = System.nanoTime(); playing = isPlaying; speed = spd <= 0 ? 1 : spd;
            }
        }
    }
    public void clear() {
        synchronized (lock) { if (id == null) return; id = null; key = ""; lines = new ArrayList<>(); chunks = new ArrayList<>(); playing = false; fetchGen++; }
    }
    private double positionRaw() { return anchorPos + (playing ? (System.nanoTime() - anchorNs) / 1e9 * speed : 0); }
    private double position() { return Math.max(0, positionRaw() - offset); }

    // ---- lirik ----
    static final Pattern NOISE = Pattern.compile("\\b(official|lyrics?|lyric video|music video|video|audio|hd|4k|mv|topic|nightcore|sped up|slowed|reverb|visualizer)\\b", Pattern.CASE_INSENSITIVE);
    static String cleanTitle(String t) {
        t = t.replaceAll("[\\(\\[\\{].*?[\\)\\]\\}]", " ");
        t = NOISE.matcher(t).replaceAll(" ").replaceAll("[|•·_\"]+", " ").replaceAll("\\s+", " ").trim();
        return t.replaceAll("^-\\s+|\\s+-$", "").trim();
    }
    static List<Line> parseLrc(String lrc) {
        List<Line> out = new ArrayList<>();
        Pattern p = Pattern.compile("\\[(\\d+):(\\d+(?:\\.\\d+)?)\\]");
        for (String raw : lrc.split("\n")) {
            Matcher m = p.matcher(raw); List<Double> ts = new ArrayList<>(); int end = 0;
            while (m.find() && m.start() == end) { ts.add(Integer.parseInt(m.group(1)) * 60 + Double.parseDouble(m.group(2))); end = m.end(); }
            String text = raw.substring(end).trim();
            if (!ts.isEmpty() && !text.isEmpty()) for (double t : ts) out.add(new Line(t, text));
        }
        out.sort(Comparator.comparingDouble(a -> a.t));
        return out;
    }
    static Object http(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(8000); c.setReadTimeout(10000); c.setRequestProperty("User-Agent", "LyricsPlusLink/1.0 (Android)");
        if (c.getResponseCode() != 200) return null;
        try (InputStream in = c.getInputStream(); ByteArrayOutputStream bo = new ByteArrayOutputStream()) {
            byte[] b = new byte[8192]; int n; while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            return Json.parse(new String(bo.toByteArray(), StandardCharsets.UTF_8));
        }
    }
    static String enc(String s) { try { return URLEncoder.encode(s, "UTF-8"); } catch (Exception e) { return s; } }
    @SuppressWarnings("unchecked")
    private void fetchLyrics(int gen, String ttl, String art, double dur) {
        List<Line> found = new ArrayList<>(); String status = "tidak ditemukan";
        try {
            String ct = cleanTitle(ttl); if (ct.isEmpty()) ct = ttl;
            String u = LRCLIB + "/api/get?track_name=" + enc(ct) + "&artist_name=" + enc(art) + (dur > 0 ? "&duration=" + Math.round(dur) : "");
            Object o = http(u);
            if (o instanceof Map) { Object s = ((Map<String, Object>) o).get("syncedLyrics"); if (s instanceof String) { found = parseLrc((String) s); if (!found.isEmpty()) status = "lrclib"; } }
            if (found.isEmpty()) {
                for (String q : new String[]{(art + " " + ct).trim(), ct}) {
                    Object r = http(LRCLIB + "/api/search?q=" + enc(q));
                    if (r instanceof List) {
                        double best = 1e9;
                        for (Object c : (List<Object>) r) {
                            if (!(c instanceof Map)) continue; Map<String, Object> m = (Map<String, Object>) c;
                            if (!(m.get("syncedLyrics") instanceof String)) continue;
                            List<Line> l = parseLrc((String) m.get("syncedLyrics")); if (l.isEmpty()) continue;
                            double d = m.get("duration") instanceof Number ? ((Number) m.get("duration")).doubleValue() : 0;
                            double diff = dur > 0 && d > 0 ? Math.abs(d - dur) : 500;
                            if (diff < best) { best = diff; found = l; status = "lrclib (pencarian)"; }
                        }
                    }
                    if (!found.isEmpty()) break;
                }
            }
        } catch (Exception e) { status = "gagal: " + e.getMessage(); }
        synchronized (lock) {
            if (gen != fetchGen) return;
            lines = found; chunks = makeChunks(found); lyricsStatus = status;
            if (duration <= 0 && !found.isEmpty()) duration = found.get(found.size() - 1).t + 15;
        }
        log("Lirik: " + status + ", " + found.size() + " baris");
    }
    static String clean(String s) {
        if (s == null) return "";
        return s.replace("|", "/").replace(";;", ";").replace("~", "-").replace("\"", "'").replace("\\", "/").replace("\n", " ").replace("\r", " ").replace("§", "").trim();
    }
    static List<String> makeChunks(List<Line> ls) {
        List<String> out = new ArrayList<>(); String cur = "";
        for (Line l : ls) {
            String text = clean(l.text); if (text.isEmpty()) continue;
            String piece = String.format(Locale.US, "%.2f~%s", l.t, text);
            String add = cur.isEmpty() ? piece : ";;" + piece;
            if (!cur.isEmpty() && cur.length() + add.length() > CHUNK) { out.add(cur); cur = piece; } else cur += add;
        }
        if (!cur.isEmpty()) out.add(cur);
        return out;
    }

    // ---- perintah chat (!geser dll.) ----
    String command(String m) {
        m = m.trim(); if (m.startsWith("!")) m = m.substring(1).trim();
        String verb = m, arg = ""; int sp = m.indexOf(' '); if (sp > 0) { verb = m.substring(0, sp); arg = m.substring(sp + 1).trim(); }
        verb = verb.toLowerCase();
        switch (verb) {
            case "geser": case "offset":
                try { double d = Double.parseDouble(arg.replace(',', '.')); synchronized (lock) { offset = Math.round((offset + d) * 10) / 10.0; return String.format(Locale.US, "Geser lirik sekarang %+.1f detik", offset); } }
                catch (Exception e) { return "Contoh: !geser 0.5 (lirik lebih lambat) atau !geser -0.5 (lebih cepat)"; }
            case "reset": synchronized (lock) { offset = 0; } return "Geser lirik direset";
            case "status": return nowPlaying();
            default: return "Perintah: !geser 0.5 | !geser -0.5 | !reset | !status. Lagu & posisi otomatis dari aplikasi musik.";
        }
    }

    // ---- server WebSocket ----
    public synchronized void start() {
        if (started) return;
        try { server = new ServerSocket(); server.setReuseAddress(true); server.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), PORT)); }
        catch (IOException e) { log("Gagal membuka port " + PORT + ": " + e.getMessage()); return; }
        started = true; log("Siap. Di Minecraft ketik: /connect 127.0.0.1:" + PORT);
        Thread t = new Thread(() -> {
            while (!server.isClosed()) {
                try { final Socket s = server.accept(); Thread h = new Thread(() -> handle(s)); h.setDaemon(true); h.start(); }
                catch (IOException e) { break; }
            }
        }); t.setDaemon(true); t.start();
    }
    public synchronized void stop() { try { if (server != null) server.close(); } catch (IOException ignored) {} started = false; }

    static byte[] frame(String text) {
        byte[] d = text.getBytes(StandardCharsets.UTF_8); ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(0x81);
        if (d.length < 126) o.write(d.length);
        else if (d.length < 65536) { o.write(126); o.write(d.length >> 8); o.write(d.length & 255); }
        else { o.write(127); for (int i = 7; i >= 0; i--) o.write((int) (((long) d.length >> (8 * i)) & 255)); }
        o.write(d, 0, d.length); return o.toByteArray();
    }
    static String cmdMsg(String command) {
        return "{\"header\":{\"version\":1,\"requestId\":\"" + UUID.randomUUID() + "\",\"messagePurpose\":\"commandRequest\",\"messageType\":\"commandRequest\"},\"body\":{\"version\":1,\"commandLine\":" + Json.quote(command) + ",\"origin\":{\"type\":\"player\"}}}";
    }
    private void say(String text) {
        String c = "tellraw @a {\"rawtext\":[{\"text\":" + Json.quote("§d[LyricsPlus] §f" + text) + "}]}";
        synchronized (queues) { for (List<String> q : queues) q.add(c); }
    }
    private void handle(Socket sock) {
        List<String> outq = new ArrayList<>();
        boolean ws = false;
        try {
            sock.setSoTimeout(5000);
            InputStream in = sock.getInputStream(); OutputStream out = sock.getOutputStream();
            ByteArrayOutputStream hb = new ByteArrayOutputStream(); int st = 0, b;
            while (st < 4 && (b = in.read()) >= 0) { hb.write(b); st = (b == '\r' && (st == 0 || st == 2)) || (b == '\n' && (st == 1 || st == 3)) ? st + 1 : (b == '\r' ? 1 : 0); if (hb.size() > 16384) return; }
            String[] hl = hb.toString("ISO-8859-1").split("\r\n"); Map<String, String> hdr = new HashMap<>();
            for (int i = 1; i < hl.length; i++) { int c = hl[i].indexOf(':'); if (c > 0) hdr.put(hl[i].substring(0, c).trim().toLowerCase(), hl[i].substring(c + 1).trim()); }
            String ukey = hdr.get("sec-websocket-key");
            if (ukey == null || !"websocket".equalsIgnoreCase(hdr.getOrDefault("upgrade", ""))) {
                String body = "{\"connected\":" + connected + ",\"now\":" + Json.quote(nowPlaying()) + "}";
                byte[] bb = body.getBytes(StandardCharsets.UTF_8);
                out.write(("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: " + bb.length + "\r\nConnection: close\r\n\r\n").getBytes()); out.write(bb); out.flush(); return;
            }
            String acc = Base64.getEncoder().encodeToString(MessageDigest.getInstance("SHA-1").digest((ukey + GUID).getBytes()));
            out.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " + acc + "\r\n\r\n").getBytes()); out.flush();
            ws = true; connected++; log("Minecraft terhubung");
            synchronized (queues) { queues.add(outq); }
            out.write(frame("{\"header\":{\"version\":1,\"requestId\":\"" + UUID.randomUUID() + "\",\"messageType\":\"commandRequest\",\"messagePurpose\":\"subscribe\"},\"body\":{\"eventName\":\"PlayerMessage\"}}")); out.flush();
            outq.add("tellraw @a {\"rawtext\":[{\"text\":\"§d[LyricsPlus] §aTerhubung. §fPutar lagu di Spotify/YouTube Music. §e!bantuan§f untuk perintah.\"}]}");
            sock.setSoTimeout(250);
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            String sentId = null; long tSent = 0, linesSent = 0;
            byte[] tmp = new byte[65536];
            while (!sock.isClosed()) {
                try {
                    int n = in.read(tmp); if (n < 0) break; buf.write(tmp, 0, n);
                    byte[] a = buf.toByteArray(); int pos = 0;
                    while (true) {
                        if (a.length - pos < 2) break;
                        int op = a[pos] & 15; boolean masked = (a[pos + 1] & 0x80) != 0; long len = a[pos + 1] & 0x7F; int i = pos + 2;
                        if (len == 126) { if (a.length - pos < 4) break; len = ((a[pos + 2] & 255) << 8) | (a[pos + 3] & 255); i = pos + 4; }
                        else if (len == 127) { if (a.length - pos < 10) break; len = 0; for (int k = 0; k < 8; k++) len = (len << 8) | (a[pos + 2 + k] & 255); i = pos + 10; }
                        byte[] mask = null; if (masked) { if (a.length < i + 4) break; mask = Arrays.copyOfRange(a, i, i + 4); i += 4; }
                        if (a.length - i < len) break;
                        byte[] pl = Arrays.copyOfRange(a, i, i + (int) len);
                        if (masked) for (int k = 0; k < pl.length; k++) pl[k] ^= mask[k % 4];
                        pos = i + (int) len;
                        if (op == 8) return;
                        if (op == 9) { out.write(new byte[]{(byte) 0x8A, (byte) pl.length}); out.write(pl); }
                        if (op == 1) onMessage(new String(pl, StandardCharsets.UTF_8));
                    }
                    buf.reset(); buf.write(a, pos, a.length - pos);
                } catch (SocketTimeoutException ignored) {}
                List<String> send = new ArrayList<>();
                synchronized (queues) { send.addAll(outq); outq.clear(); }
                long now = System.nanoTime();
                String tsend = null;
                synchronized (lock) {
                    if (id == null) { if (now - tSent >= 2e9) { send.add("scriptevent lp:t -|0|0|0|0|-|-"); tSent = now; } }
                    else {
                        boolean fresh = !id.equals(sentId) || now - linesSent >= 20e9;
                        if (fresh) { for (int k = 0; k < chunks.size(); k++) send.add("scriptevent lp:l " + id + "|" + k + "|" + chunks.size() + "|" + chunks.get(k)); sentId = id; linesSent = now; }
                        if (fresh || now - tSent >= 2e9) {
                            double d = duration > 0 ? duration : (lines.isEmpty() ? 240 : lines.get(lines.size() - 1).t + 15);
                            send.add(String.format(Locale.US, "scriptevent lp:t %s|%d|%.2f|%.1f|%d|%s|%s", id, playing ? 1 : 0, Math.min(position(), d), d, chunks.size(), clean(title), clean(artist)));
                            tSent = now;
                        }
                    }
                }
                for (String c : send) { out.write(frame(cmdMsg(c))); out.flush(); try { Thread.sleep(120); } catch (InterruptedException e) { return; } }
            }
        } catch (Exception e) { /* Minecraft menutup sambungan: normal */ }
        finally {
            if (ws) { connected--; log("Minecraft terputus"); synchronized (queues) { queues.remove(outq); } }
            try { sock.close(); } catch (IOException ignored) {}
        }
    }
    @SuppressWarnings("unchecked")
    private void onMessage(String js) {
        try {
            Object o = Json.parse(js); if (!(o instanceof Map)) return;
            Map<String, Object> j = (Map<String, Object>) o; Map<String, Object> h = (Map<String, Object>) j.get("header"); Map<String, Object> b = (Map<String, Object>) j.get("body");
            if (h == null || b == null || !"PlayerMessage".equals(h.get("eventName"))) return;
            Object msg = b.get("message"); if (!(msg instanceof String)) { Object pr = b.get("properties"); if (pr instanceof Map) msg = ((Map<String, Object>) pr).get("Message"); }
            if (msg instanceof String && ((String) msg).trim().startsWith("!")) say(command((String) msg));
        } catch (Exception ignored) {}
    }
    /** Hanya untuk tes. */
    public String debugStatus() { synchronized (lock) { return nowPlaying() + " pos=" + String.format(Locale.US, "%.1f", position()); } }
}
