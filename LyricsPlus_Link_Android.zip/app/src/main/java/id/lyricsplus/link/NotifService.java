package id.lyricsplus.link;

import android.content.ComponentName;
import android.content.Context;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.service.notification.NotificationListenerService;

import java.util.List;

/**
 * Membaca sesi media yang aktif (Spotify, YouTube Music, dll.): judul, artis, durasi, dan POSISI lagu yang sebenarnya.
 * Aktif otomatis begitu izin "Akses notifikasi" diberikan. Server /connect dijalankan di sini juga.
 */
public class NotifService extends NotificationListenerService {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaSessionManager msm;
    private ComponentName me;
    private boolean running = false;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!running) return;
            try { poll(); } catch (Throwable t) { Core.I.log("Gagal membaca sesi media: " + t); }
            handler.postDelayed(this, 1000);
        }
    };

    @Override public void onListenerConnected() {
        super.onListenerConnected();
        Core.I.start();
        me = new ComponentName(this, NotifService.class);
        msm = (MediaSessionManager) getSystemService(Context.MEDIA_SESSION_SERVICE);
        Core.I.log("Izin notifikasi aktif, membaca sesi media");
        running = true;
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    @Override public void onListenerDisconnected() {
        running = false;
        handler.removeCallbacks(tick);
        super.onListenerDisconnected();
    }

    @Override public void onDestroy() {
        running = false;
        handler.removeCallbacks(tick);
        super.onDestroy();
    }

    private void poll() {
        List<MediaController> list = msm.getActiveSessions(me);
        MediaController pick = null;
        for (MediaController c : list) {                               // utamakan yang sedang bermain
            PlaybackState ps = c.getPlaybackState();
            if (ps != null && ps.getState() == PlaybackState.STATE_PLAYING && c.getMetadata() != null) { pick = c; break; }
        }
        if (pick == null) for (MediaController c : list) { if (c.getMetadata() != null) { pick = c; break; } }
        if (pick == null) { Core.I.clear(); return; }
        MediaMetadata md = pick.getMetadata();
        String title = md.getString(MediaMetadata.METADATA_KEY_TITLE);
        String artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST);
        if (artist == null || artist.isEmpty()) artist = md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST);
        double dur = md.getLong(MediaMetadata.METADATA_KEY_DURATION) / 1000.0;
        PlaybackState ps = pick.getPlaybackState();
        boolean playing = ps != null && ps.getState() == PlaybackState.STATE_PLAYING;
        double pos = 0; float speed = 1f;
        if (ps != null) {
            pos = ps.getPosition() / 1000.0; speed = ps.getPlaybackSpeed();
            if (playing && ps.getLastPositionUpdateTime() > 0) pos += (SystemClock.elapsedRealtime() - ps.getLastPositionUpdateTime()) / 1000.0 * speed;
        }
        Core.I.update(title, artist, dur, playing, pos, speed);
    }
}
